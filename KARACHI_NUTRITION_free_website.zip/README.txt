KARACHI NUTRITION - Free Static E-commerce Website

HOW TO CUSTOMIZE
1. Open index.html in any browser.
2. Search for WHATSAPP="923001234567" and replace it with your business WhatsApp number.
3. Replace sample product names, prices and descriptions in the products array.
4. Replace "PRODUCT IMAGE" areas with your own product images if desired.

FREE HOSTING
You can publish this static site for free using GitHub Pages, Netlify, or Cloudflare Pages.
